 <!--#Sidebar 2-->
<aside id="sidebar-small" class="three columns  clearfix">
<?php  dynamic_sidebar ("Sidebar Small");  	?>
</aside> 
<!-- /#Sidebar 2-->						
<!--#Sidebar 2-->
<aside id="sidebar" class="six columns  clearfix">
<?php  dynamic_sidebar ("Sidebar Big");  	?>
</aside> 
<!-- /#Sidebar 2-->						
