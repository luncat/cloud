= silvermag Lite Version -  WordPress Theme  =

** by ThemePacific, http://themepacific.com/

For More info and Licenes Open the readme.html file and Licenses Folder

** Installation and Support **

Thank you.
